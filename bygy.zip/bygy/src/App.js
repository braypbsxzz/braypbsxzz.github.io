import logo from './logo.svg';
import './App.css';
import newImage from './images.jpeg'; // Import the new image

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={newImage} className="App-logo" alt="logo" /> {/* Use the new image */}
        <p>
          Will you be my ValentiNina?
        </p>
        <p>
          If yes look below if not. click the fuck off my site
        </p>
        <a
          className="App-link"
          href="https://www.instagram.com/p/DFL-kjrM9IE/?igsh=Zmh0YTA5ZHVwb252"
          target="_blank"
          rel="noopener noreferrer"
        >
          I love you. so click me eh
        </a>
      </header>
    </div>
  );
}

export default App;
